%Author: Ryan Protheroe (20069587)
%Date: February 6th, 2019
function [Pspace, Nspace] = a1(plane1, plane2, plane3)
A = [plane1; plane2; plane3;];  %Creating matrix
disp("rank:" ++ rank(A))    %Personal check/interest
rrefA = rref(A);    %Getting RREF of A, 
Pspace=[rrefA(1,4); rrefA(2,4); rrefA(3,4)];    %creating Pspace matrix with values from "b" of the augmented matrix
Pspace=-Pspace      %negating Pspace to make up for Ax=b solving method
A(:,4) = [];        %removing "b" column from A
%Full rank implies 0 vector null space. MATLAB default displays
%string instead of matrix, wanted it to show matrix, only reason for switch
switch rank(A)
    case {3}
        Nspace = [0;0;0]    %displays 0 vector for full rank
    case {2,1,0}
        Nspace = null(A,'r')    %displays null space of A
        SolutionCheck = A*Pspace       %testing code
        NullCheck = A*Nspace           %testing code
        
end

