/*
 * Name: Assignment1part2.java
 * Date: January 26th, 2019
 * Author: Ryan Protheroe (20069587)
 */
package Assignment1;

class quickSort {
    //quicksort class
    public int partition(int[] list, int low, int high) {
        int pivot = list[high];
        int i = (low - 1);
        for (int j = low; j < high; j++) {
            if (list[j] <= pivot) {
                i++;
                int temp = list[i];
                list[i] = list[j];
                list[j] = temp;
            }
        }
        int temp = list[i + 1];
        list[i + 1] = list[high];
        list[high] = temp;
        return i + 1;
    }

    public void sort(int[] list, int low, int high) {
        if (low < high) {
            int partitionIndex = partition(list, low, high);
            sort(list, low, partitionIndex - 1);
            sort(list, partitionIndex + 1, high);
        }
    }
}

public class Assignment1part2 {
    //create array of even numbers, parameter is size of array wanted
    public static int[] createList(int size) {
        int[] list = new int[size];
        for (int i = 0; i < list.length; i++) {
            list[i] = ((int) Math.floor(Math.random() * 5001)) * 2; //range of 10000, only even numbers
        }
        return list;
    }

    //creates "k" array, half the array is values from the list to search through,
    //other half is odd integers/ numbers that are not able to be found.
    public static int[] searchValues(int size, int[] list) {
        int[] searchValues = new int[size];
        for (int i = 0; i < size; i++) {
            if (i < (size / 2)) {
                searchValues[i] = list[(int) Math.floor(Math.random() * (list.length))];
            } else {
                //all even numbers in generator, but added 1 to make odd
                searchValues[i] = (((int) Math.floor(Math.random() * 5000)) * 2) + 1;
            }
        }
        return searchValues;
    }

    //Searches through array in order, one by one
    public static boolean linearSearch(int[] list, int value) {
        for (int i = 0; i < list.length; i++) {
            if (list[i] == value) {
                return true;
            }
        }
        return false;
    }

    //Searches by continuously halfing its search interval until its 
    //"mid" is the value it needs 
    public static boolean binarySearch(int[] list, int value) {
        int l = 0;
        int r = list.length - 1;
        while (l <= r) {
            int mid = l + (r - l) / 2;
            if (list[mid] == value) {
                return true;
            }
            if (list[mid] < value) {
                l = mid + 1;
            } else {
                r = mid - 1;
            }
        }
        return false;
    }

    // Helper function
//    static void printArray(int[] list) {
//        int n = list.length;
//        for (int i = 0; i < n; ++i) {
//            System.out.print(list[i] + " ");
//        }
//        System.out.println();
//    }
    
    public static void main(String[] args) {
        //creating lists and setting n and k values
        int nValue = 1000;
        int[] list = createList(nValue);
        int kValue = 435;
        int[] search = searchValues(kValue, list);

        //testing linear search
        double startTime = System.nanoTime();
        for (int i = 0; i < search.length; i++) {
            linearSearch(list, search[i]);
        }
        double endTime = System.nanoTime();
        double duration = (endTime - startTime);
        System.out.println("linear Search: " + duration / 1000000);

        //testing binary search
        startTime = System.nanoTime();
        quickSort test = new quickSort();
        test.sort(list, 0, list.length - 1);
        for (int i = 0; i < search.length; i++) {
            binarySearch(list, search[i]);
        }
        endTime = System.nanoTime();
        duration = (endTime - startTime);
        System.out.println("binary Search: " + duration / 1000000);

//        //testing quicksort & binary search
//        quickSort test2 = new quickSort();
//        int list2[] = {5, 123, 6, 2, 56, 75, 23};
//        test.sort(list2, 0, list2.length - 1);
//        printArray(list2);
//        System.out.println(binarySearch(list2, 1));
    }
}
